
def addPayload():
    body = {}
    return body


