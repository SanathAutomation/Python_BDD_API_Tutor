class ApiResources:
    addEndpoint = '/v3.1/currency/INR'
    addNonExistingCurrency = '/v3.1/currency/NA'
